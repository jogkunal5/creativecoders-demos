var express = require('express');
var ntlm = require('express-ntlm');
var path = require('path');
var app = express(); // using this we can use commands, function of express in this (server.js) file
var mongojs = require('mongojs');
var db = mongojs('ideacorner'); // Means which mongodb database & collection we are going to use
var bodyParser = require('body-parser');
var multer = require('multer');
var fs = require('fs');
var http = require('http');
var superwisor = require('supervisor');

// To test whether server is running correctly
/* app.get("/", function(req, res){
 res.send("Hello world from server.js");
 }); */

app.use(express.static(__dirname + "/public")); // express.static means we are telling the server to look for static file i.e. html,css,js etc.

app.use(bodyParser.json()); // To parse the body that we received from input


app.get('/', function (req, res) {
    res.sendFile(__dirname + "/index.html");
});

var storage = multer.diskStorage({//multers disk storage settings
    destination: function (req, file, cb) {
        cb(null, './uploads/');
    },
    filename: function (req, file, cb) {
        var datetimestamp = Date.now();
        cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1]);
    }
});

app.use(multer({dest: './uploads/', storage: storage}).single('file'));

// listens for the POST request from the controller
app.post('/ideacorner', function (req, res) {
    console.log("in post contactlist");
    console.log(req.body);
    console.log(req.file);
    req.body.dt_id = process.env['USERNAME'];
    req.body.user_domain = process.env['USERDOMAIN'];
    req.body.computer_name = process.env['COMPUTERNAME'];
    req.body.logon_server = process.env['LOGONSERVER'];
    req.body.status = "Submitted";
    req.body.file = req.file;
    db.collection('ideacorner').insert(req.body, function (err, doc) {
        console.log(err);
        res.json(doc);
    });
});

//This tells the server to listen for the get request for created contactlist throughout
app.get('/ideacorner', function (req, res) {
    db.collection('ideacorner').find(function (err, docs) {
        //console.log(docs);
        res.json(docs);
    });
});

app.delete('/ideacorner/:id', function (req, res) {
    var id = req.params.id; // to get the value of id from url
    console.log(id);
    db.collection('ideacorner').remove({_id: mongojs.ObjectId(id)}, function (err, doc) {
        res.json(doc);
    });
});

app.get('/ideacorner/:id', function (req, res) {
    var id = req.params.id;
    db.collection('ideacorner').findOne({_id: mongojs.ObjectId(id)}, function (err, doc) {
        res.json(doc);
    });
});

app.put('/ideacorner/:id', function (req, res) {
    var id = req.params.id;
    console.log(req.body.name);
    db.collection('ideacorner').findAndModify({
        query: {_id: mongojs.ObjectId(id)},
        update: {$set: {
                title: req.body.title,
                description: req.body.description
            }}, new : true}, function (err, doc) {
        res.json(doc);
    });
});

app.get('/themes', function (req, res) {
    db.collection('themes').find().sort({_id: -1}, function (err, docs) {
        // docs is now a sorted array 
        console.log(docs);
        res.json(docs);
    });
});

app.post('/themes', function (req, res) {
    console.log(req.body.param);
    db.collection('themes').insert(req.body.param, function (err, doc) {
        console.log(err);
        res.json(doc);
    });
});

app.get('/download/:id', function (req, res) {
    console.log("in download");
    var id = req.params.id;
    console.log(id);
    db.collection('ideacorner').findOne({
        _id: mongojs.ObjectId(id)
    }, function (err, doc) {
        var path = doc.file['destination'] + "" + doc.file['filename'];
        console.log(path);
        res.download(path, function (err) {
            if (err) {
                console.log(err);
            }
        });
    });
});



app.listen(2000);
console.log("Server running on port 2000");