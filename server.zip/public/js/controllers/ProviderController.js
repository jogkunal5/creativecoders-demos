angular.module('ProviderApp')
    .controller('ProviderController', function ($http, $scope, $routeParams, $timeout, $window) {

        $http.get('/listcollections').success(function (response) {            
            $scope.collectionList = response;        
        });

        $scope.getCollectionData = function () {                            
            $http.get('/getcollectiondata/', {
                params:{
                    collection:$scope.collection
                }
            }).success(function (response) {
                //alert(JSON.stringify(response));
                $scope.collectionName=$scope.collection;
                $scope.providerList = response; // This will put data into our html file
            });
        };

        $timeout(function () {
            if ($routeParams.id !== undefined) {                                
                $http.get('/collectiondata/'+$routeParams.id+'/collectionName/'+$routeParams.collectionName).success(function (response) {
                    $scope.providerList = response;
                    $scope.id = response['_id'];
                });
            }
        });

        $scope.export = function (id) {
            $http({
                url: '/exports/' + id,
                method: "PUT",
                data: $scope.providerList, //this is your json data string
                headers: {
                    'Content-type': 'application/json'
                },
                responseType: 'arraybuffer'
            }).success(function (data, status, headers, config) {
                var blob = new Blob([data], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                });
                var objectUrl = URL.createObjectURL(blob);
                $window.open(objectUrl);
            }).error(function (data, status, headers, config) {
                //upload failed
                });
        };
        
    });