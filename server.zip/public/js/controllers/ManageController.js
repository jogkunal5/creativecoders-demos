angular.module('IdeaCorner')
        .controller('ManageController', function ($http, $scope, $rootScope) {

            var list = function () {
                $http.get('/contactlist').success(function (response) {
                    console.log("I got the data that I requested");
                    $scope.contactlist = response; // This will put data into our html file
                    $scope.contact = "";
                });
            };

            list();

            $scope.remove = function (id) {
                console.log(id);
                $http.delete('/contactlist/' + id).success(function (response) {
                    list();
                });
            };

            $scope.edit = function (id) {
                $rootScope.$broadcast('refresh', id);
//                $http.get('/contactlist/' + id).success(function (response) {
//                    $scope.contact = response;
//                });
            };

        });