angular.module('IdeaCorner')
        .controller('ProviderController', function ($http, $scope, $routeParams, $timeout) {

            $http.get('/providerlist').success(function (response) {
                $scope.collectionList = response;
                //$scope.providerList = ""; // This will put data into our html file
            });

            $scope.getCollectionData = function () {
                $http.get('/getcollectiondata/collection/' + $scope.collection).success(function (response) {
                    alert(JSON.stringify(response));
                });
            };

            $timeout(function () {
                if ($routeParams.id !== undefined) {
                    $http.get('/providerlist/' + $routeParams.id).success(function (response) {
                        $scope.providerList = response;
                        $scope.id = response['_id'];
                    });
                }
            });

            $scope.export = function (id) {
                $http({
                    url: '/export/' + id,
                    method: "PUT",
                    data: $scope.providerList, //this is your json data string
                    headers: {
                        'Content-type': 'application/json'
                    },
                    responseType: 'arraybuffer'
                }).success(function (data, status, headers, config) {
                    var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
                    var objectUrl = URL.createObjectURL(blob);
                    window.open(objectUrl);
                }).error(function (data, status, headers, config) {
                    //upload failed
                });
            };

        });