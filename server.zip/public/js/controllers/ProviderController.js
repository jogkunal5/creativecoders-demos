angular.module('IdeaCorner')
        .controller('ProviderController', function ($http, $scope, $routeParams) {

            $http.get('/birthdaylist').success(function (response) {
                console.log("I got the data from birthday");
                $scope.birthdaylist = response; // This will put data into our html file
            });

            if ($routeParams.id !== undefined) {
                $http.get('/birthdaylist/' + $routeParams.id).success(function (response) {
                    $scope.birthdaylist = response;
                });
            }

        });