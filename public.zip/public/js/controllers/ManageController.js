angular.module('IdeaCorner')
        .controller('ManageController', function ($http, $scope, $rootScope, $window) {

            $scope.displayedCollection = [];

            var list = function () {
                $http.get('/ideacorner').success(function (response) {
                    console.log("I got the data that I requested");
                    $scope.rowCollection = response; // This will put data into our html file
                    $scope.contact = "";
                });
            };

            list();

            $scope.remove = function (id) {
                console.log(id);
                $http.delete('/ideacorner/' + id).success(function (response) {
                    list();
                });
            };

            $scope.edit = function (id) {
                $rootScope.$broadcast('refresh', id);
//                $http.get('/contactlist/' + id).success(function (response) {
//                    $scope.contact = response;
//                });
            };

            $scope.download = function (id) {
                $http.get('/download/' + id, {responseType: 'arraybuffer'}).success(function (data, status, headers, config) {

                    var blob = new Blob([data], {
                        type: "application/pdf"
                    });

                    var objectUrl = URL.createObjectURL(blob);
                    $window.open(objectUrl);

                }).error(function (data, status, headers, config) {
                    //upload failed
                });
            };

        });
