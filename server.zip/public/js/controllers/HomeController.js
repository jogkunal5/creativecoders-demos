angular.module('ProviderApp')
    .controller('HomeController', function ($http, $scope) {               
        $http.get('/providerlist').success(function (response) {                
            $scope.providerlist = response; // This will put data into our html file
            $scope.provider = "";
                
                
//            var data = [{
//                "my country": "Spain",
//                "info info1": 0.329235716,
//                "info info2": 0.447683684,
//                "info info3": 0.447683747
//            },
//
//            {
//                "my Country ": " Chile ",
//                "info info1": 1.302673893,
//                "info info2 ": 1.357820775,
//                "info info3": 1.35626442
//            },
//
//            {
//                "my Country": "United States of America",
//                "info info1  ": 7.78805016,
//                "info info2": 26.59681951,
//                "info info3": 9.200900779
//            }];
//                    
//            for (var key in data) {
//                //                alert("Key:" + key);
//                //                alert("Value:" + data[key]);
//                var that=data[key];
//                //alert(JSON.stringify(that));
//                
//                for(var row in that){
//                    var newKey=row.trim().toLowerCase().replace(/ /g,'_');                    
//                    that[newKey] = $.trim(that[row]);                    
//                    //alert("JS=====>"+that[newKey]);
//                    //newJsonObj=that;
//                    
//                    if (newKey !== row) {
//                        delete that[row];
//                    }
//                }                
//            //alert(that[newKey]);                
//            }

//            $.each(data, function(index) {
//                var that = this;
//                $.each(that, function(key, value) {                    
//                    var trimkey = $.trim(key);
//                    var newKey=trimkey.toLowerCase().replace(/ /g,'_');
//                    
//                    //                    if (typeof value === 'string')
//                    //                    {
//                    //                        that[newKey] = $.trim(value);
//                    //                    }
//                                
//                    that[newKey] = $.trim(value);
//                    //alert("JQ=====>"+that[newKey]);
//                    
//                    if (newKey !== key) {
//                        delete that[key];
//                    }
//                });
//            });

            //alert(JSON.stringify(data));
                
        });
    });